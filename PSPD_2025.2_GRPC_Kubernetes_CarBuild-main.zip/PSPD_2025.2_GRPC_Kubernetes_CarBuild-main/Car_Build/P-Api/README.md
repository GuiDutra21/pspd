## Dependencias

python -m pip install fastapi uvicorn grpcio grpcio-tools protobuf googleapis-common-protos


## rodar

uvicorn app:app --reload --port 8000